-- AlterTable
ALTER TABLE `grouppitch` MODIFY `description` TEXT NULL;
