-- AlterTable
ALTER TABLE `grouppitch` ADD COLUMN `status` INTEGER NULL DEFAULT 1;
