-- AlterTable
ALTER TABLE `grouppitch` ADD COLUMN `images` VARCHAR(191) NULL;
