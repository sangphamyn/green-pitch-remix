import { Outlet } from "@remix-run/react";

function statistic() {
  return (
    <div>
      <Outlet />
    </div>
  );
}

export default statistic;
