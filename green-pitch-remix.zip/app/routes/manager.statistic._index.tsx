import React from "react";

function statistic() {
  return (
    <div className="w-[800px] h-[200px] mx-auto mt-10 flex justify-center items-center border-dashed border-red-700 border-2 text-2xl font-bold">
      STATISTIC
    </div>
  );
}

export default statistic;
