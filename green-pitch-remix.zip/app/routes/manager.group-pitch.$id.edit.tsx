import React from "react";

function group_pitch_edit() {
  return (
    <div className="w-[800px] h-[200px] mx-auto mt-10 flex justify-center items-center border-dashed border-red-700 border-2 text-2xl font-bold">
      EDIT GROUP PITCH PAGE
    </div>
  );
}

export default group_pitch_edit;
